Product: Parametric Sliceforms, October 2014

Designer: Chris Wundram

Support:  http://forums.obrary.com/category/designs/parametric-sliceforms

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
Parametric Sliceforms is a free open design.  It is made from acrylic or cardboard that is cut an a laser cutter.